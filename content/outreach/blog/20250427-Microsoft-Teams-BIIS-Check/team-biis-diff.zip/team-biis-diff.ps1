#usage 
#.\team-biis-diff.ps1 -team "EEE 416 All (Jan 2025)" -biiscsv "EEE_416.csv"

param(
    [string]$team = "EEE 416 All (Jan 2025)",
    [string]$biiscsv = "EEE_416.csv"
)

# Define CSV file name
$teamcsvFileName = ($team -replace ' ','_') + "_TeamMembers.csv"
$teamcsvDiffFileName = ($team -replace ' ','_') + "_BIIS_diff.csv"

Write-Host "BIIS Teams Sync"
Write-Host "by Dr. Sajid Muhaimin Choudhury, Dept of EEE, BUET"
Write-Host "https://sajid.buet.ac.bd"
Write-Host ""
Write-Host "This file would take users from $team and extract members to $teamcsvFileName."
Write-Host "It would then compare $teamcsvFileName and $biiscsv, and create $teamcsvDiffFileName"
Write-Host "If BIIS has a student that is not in Teams, it would add the student ID with ADD"
Write-Host "If Teams has a student that is not in BIIS, it would add the student ID with DROP"
# Rest of your script logic here (replace with your actual code)
Write-Host "Team: $team"
Write-Host "BIIS CSV File: $biiscsv"

# Show help if no parameters are provided
if ($PSBoundParameters.Count -eq 0) {
    $scriptName = $MyInvocation.MyCommand.Name
    Write-Host ""
    Write-Host "ERROR: No Parameters given. Pass parameters." -ForegroundColor Red
    Write-Host "Usage: .\$scriptName [-team <TeamName>] [-biiscsv <CSVFileName>]"  -ForegroundColor Red
    Write-Host "Example: .\$scriptName -team 'EEE 101 Jan 2023' -biiscsv 'EEE_101.csv'"
    Write-Host ""
}



# Connect to Microsoft Teams
Write-Host "Connecting to Microsoft Teams...Please Enter Login Info in the separate screen..."
Connect-MicrosoftTeams

# Get Team Group ID
$selectedTeam = Get-Team -DisplayName $team

if ($null -eq $selectedTeam) {
    Write-Host "ERROR: No team found with display name '$team'. Exiting script." -ForegroundColor Red
    exit
}

# Get the members of the selected Team
$members = Get-TeamUser -GroupId $selectedTeam.GroupId

# Sort members by Email Address
$sortedMembers = $members | Sort-Object User

# Prepare data
$memberDetails = foreach ($member in $sortedMembers) {
    [PSCustomObject]@{
        "Display Name"  = $member.Name
        "Email Address" = $member.User
        "Role"                   = $member.Role
    }
}



# Export to CSV
$memberDetails | Export-Csv -Path $teamcsvFileName -NoTypeInformation -Encoding UTF8

Write-Host "Team members exported successfully to $teamcsvFileName" -ForegroundColor Green


# 2
# Import BIIS data without headers
$BIISData = Import-Csv -Path $biiscsv -Header "StudentID", "Name", "PersonalEmail", "OfficialEmail", "PhoneNumber"

# Extract official emails from BIIS data
$BIIS_OfficialEmails = $BIISData | Where-Object { $_.OfficialEmail -and $_.OfficialEmail.Trim() -ne "" } | Select-Object -ExpandProperty OfficialEmail

# Import Teams data
$TeamsData = Import-Csv -Path $teamcsvFileName

# Filter Teams data to include only members
$Teams_Members = $TeamsData | Where-Object { $_.Role -eq "member" }

# Extract email addresses from Teams members
$Teams_Emails = $Teams_Members | Where-Object { $_."Email Address" -and $_."Email Address".Trim() -ne "" } | Select-Object -ExpandProperty "Email Address"

# Determine emails to add (in BIIS but not in Teams)
$EmailsToAdd = $BIIS_OfficialEmails | Where-Object { $_ -notin $Teams_Emails }

# Determine emails to drop (in Teams but not in BIIS)
$EmailsToDrop = $Teams_Emails | Where-Object { $_ -notin $BIIS_OfficialEmails }

# Prepare the output data
$OutputData = @()

foreach ($email in $EmailsToAdd) {
    $OutputData += [PSCustomObject]@{
        Email   = $email
        Command = "ADD"
    }
}

foreach ($email in $EmailsToDrop) {
    $OutputData += [PSCustomObject]@{
        Email   = $email
        Command = "DROP"
    }
}

# Export the results to a CSV fil
 
$OutputData | Export-Csv -Path $teamcsvDiffFileName -NoTypeInformation -Encoding UTF8

Write-Host "$teamcsvDiffFileName has been created successfully." -ForegroundColor Green
