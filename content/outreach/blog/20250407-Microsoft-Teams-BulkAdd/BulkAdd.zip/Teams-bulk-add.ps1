# Define Team display name
$TeamDisplayName = "EEE 415 A (Jan 2025)"


# Ensure ImportExcel module is installed
if (!(Get-Module -ListAvailable -Name ImportExcel)) {
    Write-Host "ImportExcel module not found, installing..."
    Install-Module ImportExcel -Scope CurrentUser -Force
} else {
    Write-Host "ImportExcel module already installed."
}

# Ensure MicrosoftTeams module is installed
if (!(Get-Module -ListAvailable -Name MicrosoftTeams)) {
    Write-Host "MicrosoftTeams module not found, installing..."
    Install-Module MicrosoftTeams -Scope CurrentUser -Force
} else {
    Write-Host "MicrosoftTeams module already installed."
}

# Import required modules
Import-Module ImportExcel
Import-Module MicrosoftTeams

# Connect to Microsoft Teams
Write-Host "Connecting to Microsoft Teams..."
Connect-MicrosoftTeams

# Get Team Group ID
$team = Get-Team -DisplayName $TeamDisplayName

if ($null -eq $team) {
    Write-Host "No team found with display name '$TeamDisplayName'. Exiting script."
    exit
}

$groupId = $team.GroupId
Write-Host "Team '$TeamDisplayName' found. Group ID: $groupId"

# Read data from BulkAdd.xlsx (assuming file is in the same folder as script)
$scriptPath = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
$excelPath = Join-Path $scriptPath "BulkAdd.xlsx"

if (!(Test-Path $excelPath)) {
    Write-Host "File 'BulkAdd.xlsx' not found in script directory. Exiting script."
    exit
}

# Read the Excel sheet named "PowerShellData"
$data = Import-Excel -Path $excelPath -WorksheetName "PowerShellData"
Write-Host "Debugging imported data:"
$data | Format-Table

foreach ($row in $data) {
    $email = $row | Select-Object -ExpandProperty (Get-Member -InputObject $row -MemberType NoteProperty | Select-Object -First 1 -ExpandProperty Name)
    $role = $row | Select-Object -ExpandProperty (Get-Member -InputObject $row -MemberType NoteProperty | Select-Object -Skip 1 -First 1 -ExpandProperty Name)

    if ([string]::IsNullOrEmpty($email) -or [string]::IsNullOrEmpty($role)) {
        Write-Host "Empty email or role found. Skipping..."
        break
    }

    Write-Host "Email: $email, Role: $role"

    #Add users to team (uncomment the following line to add users to the team)
    Add-TeamUser -GroupId $groupId -User $email -Role $role
}

Write-Host "Process completed."