# Define Team display name
$TeamDisplayName = "EEE 415 A (Jan 2025)"

# Connect to Microsoft Teams
Write-Host "Connecting to Microsoft Teams..."
Connect-MicrosoftTeams

# Get Team Group ID
$selectedTeam = Get-Team -DisplayName $TeamDisplayName

if ($null -eq $selectedTeam) {
    Write-Host "No team found with display name '$TeamDisplayName'. Exiting script."
    exit
}



if (-not $selectedTeam) {
    Write-Error "Team '$teamName' not found. Exiting script."
    exit
}

# Get the members of the selected Team
$members = Get-TeamUser -GroupId $selectedTeam.GroupId

# Sort members by Email Address
$sortedMembers = $members | Sort-Object User

# Prepare data
$memberDetails = foreach ($member in $sortedMembers) {
    [PSCustomObject]@{
        "Display Name"  = $member.Name
        "Email Address" = $member.User
        "Role"          = $member.Role
    }
}

# Install ImportExcel Module if not already installed
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Install-Module -Name ImportExcel -Scope CurrentUser -Force
}

# Import the ImportExcel module
Import-Module ImportExcel

# Define Excel file name
$excelFileName = ($selectedTeam.DisplayName -replace ' ','_') + "_TeamMembers.xlsx"

# Export to Excel
$memberDetails | Export-Excel -Path $excelFileName -AutoSize -WorksheetName "Team Members"

Write-Host "Team members exported successfully to $excelFileName" -ForegroundColor Green

